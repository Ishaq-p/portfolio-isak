"use client";
import Link from "next/link";
import OrbitMark from "./OrbitMark";
import { FaLinkedinIn, FaGithub } from "react-icons/fa6";

const stats = [
  { label: "Projects shipped", value: "8+" },
  { label: "Research", value: "Active" },
  { label: "Verbal Languages", value: "5" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0B0E13] text-[#F6F6F3]/50 pt-20 pb-10 border-t border-[#F6F6F3]/10 selection:bg-[#4A54F1] selection:text-[#F6F6F3]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-12 gap-12 pb-16 border-b border-[#F6F6F3]/10">
          {/* Identity */}
          <div className="md:col-span-5 space-y-6">
            <Link href="/" className="flex items-center gap-2.5 w-fit group">
              <OrbitMark size="sm" tone="ion" />
              <span
                className="text-lg font-black text-[#F6F6F3] uppercase tracking-widest"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Paktinyar
              </span>
            </Link>
            <p className="text-sm font-light leading-relaxed max-w-sm text-[#F6F6F3]/60">
              Software engineer and bioinformatics researcher based in Istanbul. 
              Building backend systems and applied ML, one careful decision at a time.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-none flex items-center justify-center hover:bg-[#F6F6F3] hover:text-[#0B0E13] text-[#F6F6F3] transition-colors"
                aria-label="GitHub"
              >
                <FaGithub className="text-[15px]" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-none flex items-center justify-center hover:bg-[#F6F6F3] hover:text-[#0B0E13] text-[#F6F6F3] transition-colors"
                aria-label="LinkedIn"
              >
                <FaLinkedinIn className="text-[15px]" />
              </a>
            </div>
          </div>

          {/* Nav */}
          <div className="md:col-span-3 space-y-5 mt-2">
            <p className="font-mono text-xs uppercase tracking-widest text-[#4A54F1]">Navigate</p>
            <div className="flex flex-col gap-4 text-sm font-light text-[#F6F6F3]/60">
              <Link href="/" className="hover:text-[#F6F6F3] transition-colors w-fit">Home</Link>
              <Link href="/portfolio" className="hover:text-[#F6F6F3] transition-colors w-fit">Work</Link>
              <Link href="/portfolio#experiences" className="hover:text-[#F6F6F3] transition-colors w-fit">Experience</Link>
              <a href="#contact-section" className="hover:text-[#F6F6F3] transition-colors w-fit">Contact</a>
            </div>
          </div>

          {/* Stats - Brutalist Wireframe */}
          <div className="md:col-span-4 mt-2">
            <p className="font-mono text-xs uppercase tracking-widest text-[#4A54F1] mb-5">Telemetry</p>
            <div className="grid grid-cols-2 gap-px bg-[#F6F6F3]/20">
              {stats.map((s, i) => (
                <div 
                  key={s.label} 
                  className={`p-5 bg-[#0B0E13] flex flex-col justify-between ${i === 2 ? 'col-span-2 flex-row items-center' : 'aspect-square'}`}
                >
                  <div className="text-[10px] font-mono text-[#F6F6F3]/40 uppercase tracking-wider">{s.label}</div>
                  <div className="text-3xl font-black text-[#F6F6F3]" style={{ fontFamily: "var(--font-display)" }}>
                    {s.value}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#F6F6F3]/30 uppercase">
            © {new Date().getFullYear()} ISHAQ PAKTINYAR. SYS_ONLINE.
          </p>
          <div className="flex items-center gap-2 font-mono text-xs text-[#F6F6F3]/40 uppercase">
            <span className="w-2 h-2 rounded-none bg-[#4A54F1] animate-pulse" />
            Accepting Load
          </div>
        </div>
      </div>
    </footer>
  );
}