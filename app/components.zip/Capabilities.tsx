"use client";
import React, { useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { LuServer, LuDna, LuDatabase, LuWorkflow } from "react-icons/lu";

const capabilities = [
  {
    title: "Backend Architecture",
    desc: "Distributed API gateways and high-concurrency production clusters.",
    tech: "Next.js — Nest.js — Python - Java ",
    metric: { label: "Latency", value: "14ms" },
    icon: LuServer,
    accent: "ion",
  },
  {
    title: "Bio-Neural ML",
    desc: "Sequence-to-function mapping and protein classification pipelines.",
    tech: "PyTorch — ATGC — CNN - PLM - LLM",
    metric: { label: "Accuracy", value: "98%" },
    icon: LuDna,
    accent: "culture",
  },
  {
    title: "Hybrid Data Systems",
    desc: "Centralized RDBMS architecture replacing legacy distributed spreadsheets.",
    tech: "Postgres — Redis - ORM - DBMS - GraphQL",
    metric: { label: "Users", value: "1.8k+" },
    icon: LuDatabase,
    accent: "ion",
  },
  {
    title: "Automation Ops",
    desc: "Replacing manual workflows with autonomous decision-support systems.",
    tech: "Git — Docker — AWS - VPS - Bash",
    metric: { label: "Efficiency", value: "+60%" },
    icon: LuWorkflow,
    accent: "culture",
  },
];

export default function Capabilities() {
  return (
    <section className="py-28 bg-paper overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-end justify-between flex-wrap gap-6 mb-16">
          <div className="space-y-4">
            <p className="label-eyebrow text-ion">Core Competencies</p>
            <h2
              className="text-4xl sm:text-5xl font-semibold tracking-tight text-ink text-balance"
              style={{ fontFamily: "var(--font-display)" }}
            >
              System capabilities.
            </h2>
          </div>
          <p className="text-graphite text-sm max-w-xs leading-relaxed">
            Four areas where I spend most of my working hours — from raw sequence data to production traffic.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {capabilities.map((cap, i) => (
            <TiltCard key={cap.title} cap={cap} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TiltCard({ cap, index }: { cap: (typeof capabilities)[number]; index: number }) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x, { stiffness: 200, damping: 20 });
  const mouseYSpring = useSpring(y, { stiffness: 200, damping: 20 });

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["7deg", "-7deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-7deg", "7deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    x.set((e.clientX - rect.left) / rect.width - 0.5);
    y.set((e.clientY - rect.top) / rect.height - 0.5);
  };
  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const Icon = cap.icon;
  const accentColor = cap.accent === "ion" ? "var(--ion)" : "var(--culture)";

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className="group relative h-[360px] w-full rounded-[1.75rem] bg-ink"
    >
      <div
        className="absolute inset-0 rounded-[1.75rem] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{ background: `radial-gradient(circle at 50% 0%, ${accentColor}33 0%, transparent 65%)` }}
      />

      <div
        style={{ transform: "translateZ(40px)", transformStyle: "preserve-3d" }}
        className="absolute inset-3 flex flex-col justify-between rounded-[1.4rem] bg-paper p-7"
      >
        <div className="space-y-5">
          <div className="flex justify-between items-start">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
              style={{ background: `${accentColor}14`, color: accentColor }}
            >
              <Icon />
            </div>
            <div className="text-right">
              <p className="label-eyebrow text-graphite-2">{cap.metric.label}</p>
              <p className="text-sm font-semibold text-ink" style={{ fontFamily: "var(--font-display)" }}>
                {cap.metric.value}
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-ink mb-2.5 tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              {cap.title}
            </h3>
            <p className="text-graphite text-[13px] leading-relaxed">{cap.desc}</p>
          </div>
        </div>

        <div className="pt-5 border-t border-ink/[0.07]">
          <p className="font-mono text-[10px] font-medium text-graphite-2 tracking-tight">{cap.tech}</p>
        </div>
      </div>
    </motion.div>
  );
}
