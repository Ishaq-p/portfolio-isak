"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { LuMenu, LuX, LuChevronDown, LuArrowUpRight } from "react-icons/lu";
import OrbitMark from "./OrbitMark";

export default function Navbar() {
  const pathname = usePathname();
  
  // Define which routes should use the light theme. 
  // Add any other light pages to this array.
  const isLight = ["/portfolio", "/about"].includes(pathname);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [resumeOpen, setResumeOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const resumes = [
    { label: "English", sub: "CV — EN", path: "/ishaq_cv.pdf" },
    { label: "Türkçe", sub: "CV — TR", path: "/ishaq_cv-turkish.pdf" },
  ];
  
  // Theme dictionaries driven dynamically by the route
  const fg = isLight ? "text-[#0B0E13]" : "text-[#F6F6F3]";
  const fgMuted = isLight ? "text-[#0B0E13]/60" : "text-[#F6F6F3]/60";
  const border = isLight ? "border-[#0B0E13]/20" : "border-[#F6F6F3]/20";
  const bgNav = isLight ? "bg-[#F6F6F3]/90" : "bg-[#0B0E13]/90";
  const bgDropdown = isLight ? "bg-[#F6F6F3]" : "bg-[#0B0E13]";
  const btnHover = isLight ? "hover:bg-[#0B0E13] hover:text-[#F6F6F3]" : "hover:bg-[#F6F6F3] hover:text-[#0B0E13]";

  return (
    <nav
      className={`fixed w-full top-0 z-50 transition-all duration-300 px-6 md:px-10 ${
        scrolled
          ? `${bgNav} backdrop-blur-md border-b ${border} py-3`
          : "bg-transparent border-b border-transparent py-5"
      }`}
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 group">
          <OrbitMark size="xs" tone="ion" />
          <span
            className={`text-[15px] font-semibold tracking-tight ${fg}`}
            style={{ fontFamily: "var(--font-display)" }}
          >
            Paktinyar
          </span>
        </Link>

        <div className={`hidden md:flex items-center gap-9 text-[13px] font-medium ${fgMuted}`}>
          <Link href="/" className={`hover:${fg.replace("text-", "text-")} transition-colors`}>
            Home
          </Link>
          <Link href="/portfolio" className={`hover:${fg.replace("text-", "text-")} transition-colors`}>
            Work
          </Link>

          <div
            className="relative"
            onMouseEnter={() => setResumeOpen(true)}
            onMouseLeave={() => setResumeOpen(false)}
          >
            <span className={`hover:${fg.replace("text-", "text-")} transition-colors flex items-center gap-1.5 cursor-pointer`}>
              Résumé <LuChevronDown className="text-[11px]" />
            </span>
            <AnimatePresence>
              {resumeOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{ duration: 0.15 }}
                  className="absolute top-full right-0 pt-3 w-44"
                >
                  <div className={`${bgDropdown} border ${border} rounded-none p-1.5 shadow-xl shadow-black/10`}>
                    {resumes.map((res) => (
                      <Link
                        key={res.label}
                        href={res.path}
                        target="_blank"
                        className={`flex items-center justify-between px-3.5 py-2.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-none group/item transition-colors`}
                      >
                        <div className="flex flex-col">
                          <span className={`text-[12px] font-medium ${fg}`}>{res.label}</span>
                          <span className={`text-[10px] ${fgMuted}`}>{res.sub}</span>
                        </div>
                        <LuArrowUpRight
                          size={12}
                          className={`${fgMuted} group-hover/item:text-[#4A54F1] group-hover/item:translate-x-0.5 group-hover/item:-translate-y-0.5 transition-all`}
                        />
                      </Link>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <a
            href="#contact-section"
            className={`px-5 py-2.5 rounded-none border ${border} bg-transparent ${fg} text-[12px] font-mono uppercase tracking-widest ${btnHover} transition-colors duration-300`}
          >
            Initialize
          </a>
        </div>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className={`md:hidden p-2 -mr-2 ${fg}`}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <LuX size={22} /> : <LuMenu size={22} />}
        </button>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className={`md:hidden overflow-hidden ${bgDropdown} border-b ${border}`}
          >
            <div className="flex flex-col pt-6 pb-6 px-6 gap-5">
              <Link href="/" onClick={() => setIsMobileMenuOpen(false)} className={`text-[15px] font-medium ${fg}`}>
                Home
              </Link>
              <Link
                href="/portfolio"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`text-[15px] font-medium ${fg}`}
              >
                Work
              </Link>
              <a
                href="#contact-section"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`text-[15px] font-medium ${fg}`}
              >
                Initialize
              </a>

              <div className={`pt-4 border-t ${border} space-y-2`}>
                <p className={`font-mono text-xs ${fgMuted} mb-3 uppercase`}>Résumé</p>
                {resumes.map((res) => (
                  <Link
                    key={res.label}
                    href={res.path}
                    target="_blank"
                    className={`flex items-center justify-between p-3.5 bg-black/5 dark:bg-white/5 rounded-none border ${border}`}
                  >
                    <div>
                      <p className={`text-[13px] font-medium ${fg}`}>{res.label}</p>
                      <p className={`text-[11px] ${fgMuted}`}>{res.sub}</p>
                    </div>
                    <LuArrowUpRight className="text-[#4A54F1]" size={14} />
                  </Link>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}