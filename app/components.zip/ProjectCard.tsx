"use client";
import Link from "next/link";
import { motion } from "framer-motion";
import { LuArrowUpRight } from "react-icons/lu";

const STATUS_STYLE: Record<string, { dot: string; text: string }> = {
  Production: { dot: "bg-culture-soft", text: "text-culture-soft" },
  "Ongoing Research": { dot: "bg-ion-soft", text: "text-ion-soft" },
  Thesis: { dot: "bg-white/50", text: "text-white/60" },
  "Academic Project": { dot: "bg-white/50", text: "text-white/60" },
};

export default function ProjectCard({ project }: any) {
  if (!project?.short_card) return null;
  const { short_card } = project;
  const status = STATUS_STYLE[short_card.status] ?? STATUS_STYLE["Thesis"];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4 }}
      className="group relative h-full w-full flex flex-col bg-ink border border-white/[0.08] rounded-[1.5rem] overflow-hidden hover:border-ion/40 transition-all duration-500"
    >
      <div className="absolute -right-16 -bottom-16 w-52 h-52 bg-ion/[0.08] blur-[80px] rounded-full pointer-events-none group-hover:bg-ion/[0.14] transition-all duration-700" />

      <div className="relative z-10 flex flex-col h-full p-7 gap-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1.5">
            <h3
              className="text-xl font-semibold text-white tracking-tight leading-tight"
              style={{ fontFamily: "var(--font-display)" }}
            >
              {short_card.title}
            </h3>
            <p className="text-[11px] font-medium uppercase tracking-wider text-white/35">
              {short_card.role} · {short_card.year}
            </p>
          </div>
          <span className={`shrink-0 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide px-2.5 py-1 rounded-full bg-white/[0.06] border border-white/10 ${status.text}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
            {short_card.status}
          </span>
        </div>

        <p className="text-[13.5px] text-white/55 leading-relaxed">{short_card.tagline}</p>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/[0.07]">
            <p className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/30 mb-1.5">
              {short_card.key_metric?.label}
            </p>
            <p className="text-xl font-semibold text-white tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              {short_card.key_metric?.value}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/[0.07]">
            <p className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/30 mb-1.5">
              {short_card.secondary_metric?.label}
            </p>
            <p className="text-xl font-semibold text-ion-soft tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
              {short_card.secondary_metric?.value}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {short_card.stack?.slice(0, 4).map((tech: string) => (
            <span
              key={tech}
              className="font-mono text-[10px] font-medium px-2.5 py-1 rounded-md bg-white/[0.04] text-white/45 border border-white/[0.07]"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="mt-auto pt-5 border-t border-white/[0.08]">
          <Link
            href={`/portfolio/project/${project.id}`}
            className="flex items-center justify-between w-full px-5 py-4 rounded-xl bg-white/[0.05] border border-white/[0.08] hover:bg-ion hover:border-ion transition-all duration-300 group/cta"
          >
            <span className="text-[12px] font-semibold text-white/70 group-hover/cta:text-white transition-colors">
              View case study
            </span>
            <LuArrowUpRight
              size={15}
              className="text-white/40 group-hover/cta:text-white group-hover/cta:translate-x-0.5 group-hover/cta:-translate-y-0.5 transition-all duration-200"
            />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
