"use client";
import { motion } from "framer-motion";

interface FilterProps {
  projects: any[];
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
}

export default function FilterJumble({ projects, activeFilter, setActiveFilter }: FilterProps) {
  const domains = projects?.flatMap((p) => p.short_card.domain) || [];
  const uniqueDomains = ["All", ...Array.from(new Set(domains))];

  return (
    <div className="flex flex-wrap items-center gap-2">
      {uniqueDomains.map((domain) => {
        const isActive = activeFilter === domain || (domain === "All" && activeFilter === "ALL");
        const value = domain === "All" ? "ALL" : domain;
        return (
          <button
            key={domain}
            onClick={() => setActiveFilter(value)}
            className="relative px-4 py-2 rounded-full text-[12px] font-medium transition-colors"
          >
            {isActive && (
              <motion.span
                layoutId="filter-pill"
                className="absolute inset-0 bg-ink rounded-full"
                transition={{ type: "spring", stiffness: 400, damping: 32 }}
              />
            )}
            <span className={`relative z-10 ${isActive ? "text-white" : "text-graphite hover:text-ink"}`}>
              {domain}
            </span>
          </button>
        );
      })}
    </div>
  );
}
