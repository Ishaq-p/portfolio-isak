"use client";
import { motion } from "framer-motion";
import { LuMapPin, LuArrowUpRight, LuCircleDot } from "react-icons/lu";
import Link from "next/link";

export default function ExperienceCard({ exp }: { exp: any }) {
  const isPresent = exp.duration.end === "Present";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: exp.index * 0.06 }}
      className="group relative flex flex-col bg-white/[0.03] border border-white/[0.08] rounded-2xl overflow-hidden hover:border-ion/35 transition-all duration-500"
    >
      <div className="flex flex-col h-full p-6 gap-5">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] font-medium text-white/25 tracking-widest">
            {String(exp.index).padStart(2, "0")}
          </span>
          {isPresent && (
            <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-culture/10 border border-culture/25">
              <span className="w-1 h-1 rounded-full bg-culture-soft animate-pulse" />
              <span className="text-[9px] font-semibold text-culture-soft uppercase tracking-widest">
                Active
              </span>
            </span>
          )}
          <p className="text-[10px] text-white/35 font-medium">
            {exp.duration.start} – {exp.duration.end}
          </p>
        </div>

        <div className="space-y-2">
          <h3
            className="text-xl font-semibold text-white tracking-tight leading-none"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {exp.role}
          </h3>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="text-[13px] font-medium text-ion-soft">{exp.organization}</span>
            <span className="text-white/15 text-xs hidden sm:inline">·</span>
            <span className="flex items-center gap-1 text-[11px] text-white/35">
              <LuMapPin size={10} />
              {exp.location}
            </span>
          </div>
        </div>

        <p className="text-[12.5px] text-white/45 leading-relaxed line-clamp-2">{exp.summary}</p>

        <ul className="space-y-2">
          {exp.key_impact.slice(0, 2).map((point: string, i: number) => (
            <li key={i} className="flex items-start gap-2.5">
              <LuCircleDot size={9} className="text-ion-soft/70 mt-[4px] shrink-0" />
              <span className="text-[12px] text-white/55 leading-snug">{point}</span>
            </li>
          ))}
        </ul>

        <div className="flex flex-wrap gap-1.5">
          {exp.stack.map((tech: string) => (
            <span
              key={tech}
              className="font-mono text-[9.5px] font-medium px-2 py-0.5 rounded-md bg-white/[0.04] text-white/40 border border-white/[0.07]"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-white/[0.07] mt-auto">
          <span className="text-[9.5px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-md border border-ion/25 text-ion-soft/80">
            {exp.type}
          </span>

          {exp.has_details_page ? (
            <Link
              href={exp.links.details}
              className="flex items-center gap-1.5 text-[11px] font-semibold text-white/40 hover:text-white transition-colors duration-200 group/link"
            >
              View role
              <LuArrowUpRight
                size={12}
                className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform duration-200"
              />
            </Link>
          ) : (
            <span className="text-[10px] text-white/20">—</span>
          )}
        </div>
      </div>
    </motion.div>
  );
}
